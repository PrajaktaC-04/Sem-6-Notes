
	<?php include('common/header.php') ?>
	<div class="home-div"></div>
		<div class="w-100 in-ad-ap">
			<div class="row m-auto text-center">
				<div class="col-md-4"><h3>INTRODUCING-WCE</h3></div>
				<div class="col-md-4"><h3>ADMISSION POLICY</h3></div>
				<div class="col-md-4"><h3>APPLY NOW</h3></div>
			</div>
		</div>
		<div class="paragraph">
			<p>
				WCE provides a harmonious environment and learning opportunities  to its students regardless of their gender, socioeconomic background, religious beliefs and regional differences.
			</p>
		</div>
	<?php include('common/cards.php') ?>
	<?php include('common/footer.php') ?>
</body>
</html>

