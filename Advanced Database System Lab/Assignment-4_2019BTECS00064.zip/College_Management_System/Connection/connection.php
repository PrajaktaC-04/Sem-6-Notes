<?php 
	$con=mysqli_connect("localhost","root","","walchand_college");
	if(!$con)
	{
		echo "Connection is not Successfully";
	}
?>