<footer>
  <div class="footer-top">
    <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12 segment-one md-mb-30 sm-mb-30">
            <h3>Walchand College of Engineering</h3>
            <p>This Project has been made by Kunal Kadam.
              The prupose of this project is Learning Computer Languages.
              I hope you realy enjoyed to visit this project. Thanks!
            </p>
          </div>
          <div class="col-md-2 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>Quick Links</h2>
            <ul>
              <li><a href="">About WCE</a></li>
              <li><a href="">Admissions Policy</a></li>
              <li><a href="">Apply for Admission</a></li>
              <li><a href="">Download Prospectus</a></li>
              <li><a href="">Contact Us</a></li>
            </ul>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>UNDERGRADUATE PROGRAMS</h2>
            <ul>
              <li><a href="">B.Tech. Civil Engineering</a></li>
              <li><a href="">B.Tech. Electrical Engineering</a></li>
              <li><a href="">B.Tech. Mechanical Engineering</a></li>
              <li><a href="">B.Tech. Electronics</a></li>
              <li><a href="">B.Tech. Computer Science</a></li>
              <li><a href="">B.Tech. Information Technology</a></li>
              <!-- <li><a href="">Bachelors of Business Administration</a></li> -->
            </ul>
          </div>  
          <div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>CONTACT DETAILS</h2>
              <p>Address: Walchand College of Engineering,
                  Miraj Rd, Vishrambag, Sangli,Maharashtra – India</p>
              <p>Telephones: (+91) 233-2300383</p>
              <p>E-mail: registrar@walchandsangli.ac.in</p>
        </div>
      </div>
    </div>
    </div>
  <p class="footer-bottom-text">CopyRights © reserved by Kunal Kadam.2022</p>
</footer>